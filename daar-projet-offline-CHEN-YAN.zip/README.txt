1. Pour exécuter le binaire
Les fichiers jar se trouvent dans le répertoire daar-projet-offine.
Veuillez placer le fichier à rechercher sous le chemin "src/texts" et assurez-vous que le fichier est en encodage utf8. En exécutant la commande suivante dans le terminal, vous pouvez effectuer une recherche en saisissant une expression régulière et le fichier à rechercher.
java -jar regex.jar ou java -jar regex.jar <expression régulière> <nom_fichier> 
Si votre motif est en une chaine de concaténations, la recherche KMP est plus efficace. Par conséquent, vous pouvez exécuter la commande suivante:
java -jar kmp.jar ou java -jar kmp.jar <expression> <nom_fichier> 

Lorsque la recherche est terminée, le programme renvoie la ligne entière dans laquelle se trouve le motif cible.

Si vous voulez connaître les temps d'exécution des deux stratégies de recherche pour deux modes spécifiques, vous pouvez exécuter 
java -jar performance.jar

2. Pour exécuter le code java.
Vous pouvez importer ce projet dans Eclipse, Intellij IDEA ou des autres IDEs.

3. Le répertoire "src/texts" contient les instances de test.
